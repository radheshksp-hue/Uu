# GitHub Actions: Build APK from Uploaded ZIP

This delivery contains the workflow file to commit to your GitHub repository.

## Install
1. In your repository, create `.github/workflows/build-apk.yml`.
2. Paste the included workflow or upload this file at that exact path.
3. Commit the change.
4. Open **Actions → Extract and Build Android APK → Run workflow**.
5. Download `android-debug-apk` from the successful run's Artifacts section.

## Important
- The workflow extracts the ZIP on the GitHub runner, not on your phone.
- The ZIP must contain one Android project with `settings.gradle` or `settings.gradle.kts`, `gradlew`, root Gradle build file, and an `app` module.
- The missing Gradle Wrapper JAR repair is deliberately limited to Gradle 8.13. For other versions, include the genuine Wrapper JAR.
- The workflow has not been run against your repository. A successful APK build is not guaranteed until GitHub Actions completes successfully.
- `actions/checkout`, `actions/setup-java`, `android-actions/setup-android`, and `actions/upload-artifact` are referenced by major version tags, not immutable commit SHAs.
